package com.cg.payroll.tests;

import org.easymock.EasyMock;
import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;

public class PayrollServicesTestEasyMock {
	private static PayrollServices payrollServices;
	private static AssociateDAO mockAssociateDao;
	
	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDao = EasyMock.mock(AssociateDAO.class);
		payrollServices = new PayrollServicesImpl(mockAssociateDao);			
	}
	
	@Before
	public void setUpTestMockData(){
		Associate associate1 = new Associate(1001, 970000, "Daipayan", "Guha", "JAVAFS", "Analyst", "123qw123", "dguha@gmail.com", 
				new Salary(90000, 1000, 2000), new BankDetails(97518642, "CITI", "CITI98765"));
		Associate associate2 = new Associate(1002, 970000, "Tirtharaj", "Sur", "JAVAFS", "Analyst", "123ew123", "tsur@gmail.com", 
				new Salary(90001, 1001, 2001), new BankDetails(97518643, "CITI", "CITI98766"));
		Associate associate3 = new Associate(1002, 970000, "Pritam", "Chat", "JAVAFS", "Analyst", "123ew123", "tsur@gmail.com", 
				new Salary(90001, 1001, 2001), new BankDetails(97518643, "CITI", "CITI98766"));
		
		ArrayList<Associate> associatesList = new ArrayList<>();
		associatesList.add(associate1);
		associatesList.add(associate2);
		
		EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);
		
		EasyMock.expect(mockAssociateDao.findOne(1001)).andReturn(associate1);
		EasyMock.expect(mockAssociateDao.findOne(1002)).andReturn(associate1);
		EasyMock.expect(mockAssociateDao.findOne(1234)).andReturn(null);
		EasyMock.expect(mockAssociateDao.findAll()).andReturn(associatesList);
		EasyMock.replay(mockAssociateDao);
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
		public void testGetAssociateDetailsForInvalidAssoiateId()throws AssociateDetailsNotFoundException{
		payrollServices.getAssociateDetails(1234);
		EasyMock.verify(mockAssociateDao.findOne(1234));
	}
	
	@Test
	public void testGetAssociateDetailsForValidAssoiateId()throws AssociateDetailsNotFoundException{
		Associate expectedAssociate = new Associate(1001, 970000, "Daipayan", "Guha", "JAVAFS", "Analyst", "123qw123", "dguha@gmail.com", 
				new Salary(90000, 1000, 2000), new BankDetails(97518642, "CITI", "CITI98765"));
		Associate actualAssociate = payrollServices.getAssociateDetails(1001);
		assertEquals(expectedAssociate, actualAssociate);
	EasyMock.verify(mockAssociateDao.findOne(1001));
}
	
	@AfterClass
	public static void tearDownTestEnv() {
		payrollServices = null;
		mockAssociateDao = null;
	}
}
