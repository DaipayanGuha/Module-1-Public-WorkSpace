package com.cg.payroll.tests;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;




public class PayrollServicesTest {

	/*@Test
	public void test() {
		fail("Not yet implemented");
	}*/
	
	private static PayrollServices services;
	
	@BeforeClass
	public static void setUpTestEnv() {
		services = new PayrollServicesImpl();
	}
	
	@Before
	public void setUpTestData(){
		Associate associate1 = new Associate(1001, 970000, "Daipayan", "Guha", "JAVAFS", "Analyst", "123qw123", "dguha@gmail.com", 
				new Salary(90000, 1000, 2000), new BankDetails(97518642, "CITI", "CITI98765"));
		Associate associate2 = new Associate(1002, 970000, "Tirtharaj", "Sur", "JAVAFS", "Analyst", "123ew123", "tsur@gmail.com", 
				new Salary(90001, 1001, 2001), new BankDetails(97518643, "CITI", "CITI98766"));
		
		PayrollDBUtil.associates.put(associate1.getAssociateId(),associate1);
		PayrollDBUtil.associates.put(associate2.getAssociateId(),associate2);
		
		PayrollDBUtil.ASSOCIATE_ID_COUNTER = 1002;
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testCheckAssociateDetailsAvailablityFirstName()throws AssociateDetailsNotFoundException{
		services.getAssociateDetails(12343);
	}
	
	@Test
	public void testGetAssociateDetailsForValidAssociateId()throws AssociateDetailsNotFoundException{
		Associate expectedAssociate = new Associate(1002, 970000, "Tirtharaj", "Sur", "JAVAFS", "Analyst", "123ew123", "tsur@gmail.com", 
				new Salary(90001, 1001, 2001), new BankDetails(97518643, "CITI", "CITI98766"));
		Associate actualAssociate = services.getAssociateDetails(1002);
		Assert.assertEquals(expectedAssociate, actualAssociate);
	}
	
	@Test
	public void testAcceptAssociateDetailsForValidData() {
		int expectedId = 1003;
		int actualId = services.acceptAssociateDetails("ABC", "PQR", "abc@gmail.com", "YTP", "Con", "abc123def", 12000, 90002, 1000, 2000, 86529753, "CITI", "CITI54321");
		Assert.assertEquals(expectedId, actualId);
	}
		
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId()throws AssociateDetailsNotFoundException{
			services.calculateNetSalary(1434);
	}
	
	@Test
	public void testCalculateNetSalaryForValidAssociateId()throws AssociateDetailsNotFoundException{
			double expectedNetSalary = 0;
			double actualNetSalary = services.calculateNetSalary(1002);
			Assert.assertEquals(expectedNetSalary, actualNetSalary,0);
	}
	
	@Test
	public void testGetAllAssociatesDetails() {
		Associate associate1 = new Associate(1001, 970000, "Daipayan", "Guha", "JAVAFS", "Analyst", "123qw123", "dguha@gmail.com", 
				new Salary(90000, 1000, 2000), new BankDetails(97518642, "CITI", "CITI98765"));
		Associate associate2 = new Associate(1002, 970000, "Tirtharaj", "Sur", "JAVAFS", "Analyst", "123ew123", "tsur@gmail.com", 
				new Salary(90001, 1001, 2001), new BankDetails(97518643, "CITI", "CITI98766"));
		
		ArrayList<Associate> expectedAssociateList = new ArrayList<>();
		expectedAssociateList.add(associate1);
		expectedAssociateList.add(associate2);
		ArrayList<Associate>actualAssociateList = (ArrayList<Associate>) services.getAllAssociateDetails();
		Assert.assertEquals(expectedAssociateList, actualAssociateList);
	}

	@After
	public void tearDownTestData()
	{
		PayrollDBUtil.associates.clear();
		PayrollDBUtil.ASSOCIATE_ID_COUNTER = 1000;
	}
	
	
	@AfterClass
	public static void tearDownTestEnv() {
		services = null;
	}

}
