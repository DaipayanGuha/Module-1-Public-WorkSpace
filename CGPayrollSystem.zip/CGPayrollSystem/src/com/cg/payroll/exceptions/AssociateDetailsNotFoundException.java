package com.cg.payroll.exceptions;

public class AssociateDetailsNotFoundException extends RuntimeException
{

	public AssociateDetailsNotFoundException() {
		super();
		System.out.println("Associate Details Not Found!");
	}

	public AssociateDetailsNotFoundException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		System.out.println("Associate Details Not Found!");
	}

	public AssociateDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		System.out.println("Associate Details Not Found!");
	}

	public AssociateDetailsNotFoundException(String message) {
		super(message);
		System.out.println("Associate Details Not Found!");
	}

	public AssociateDetailsNotFoundException(Throwable cause) {
		super(cause);
		System.out.println("Associate Details Not Found!");
	}
	

}
