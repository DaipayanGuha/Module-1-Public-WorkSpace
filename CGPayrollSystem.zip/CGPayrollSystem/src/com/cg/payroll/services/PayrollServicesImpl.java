package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public class PayrollServicesImpl implements PayrollServices{

	//private AssociateDAO associateDao = new AssociateDAOImpl();
	
	//For Mock
	private AssociateDAO associateDao;
	public PayrollServicesImpl() {
		 associateDao = new AssociateDAOImpl();
	}
	public PayrollServicesImpl(AssociateDAO associateDao) {
		super();
		this.associateDao = associateDao;
	}
	
	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designnation, String pancard, int yearlyInvestmentUnder8oC, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) {
			Associate associate = new Associate(yearlyInvestmentUnder8oC, firstName, lastName, department, designnation, pancard,
					emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));		
			associate = associateDao.save(associate);
		return associate.getAssociateId();
	}
	
	@Override
	public double calculateGrossSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = getAssociateDetails(associateId);
		//Associate associate=associateDao.findOne(associateId);
		return (associate.getSalary().getBasicSalary() + 0.3*associate.getSalary().getBasicSalary()*2 + .25*associate.getSalary().getBasicSalary() + .2*associate.getSalary().getBasicSalary()
				+ associate.getSalary().getCompanyPf() + associate.getSalary().getEpf());
	}
	

	@Override
	public double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		//Associate associate=associateDao.findOne(associateId);
		Associate associate = getAssociateDetails(associateId);
		return (12*calculateGrossSalary(associateId) + associate.getSalary().getCompanyPf() + associate.getSalary().getEpf());
		/*double a = associate.getSalary().getBasicSalary()-(250000+associate.getYearlyInvestmentUnder8oC()+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf());
		double b = a - 500000;
		double c = b - 1000000;
		double netSalary;
		if(associate.getSalary().getBasicSalary()<=250000) {
			netSalary = associate.getSalary().getBasicSalary();
		}
		else if(associate.getSalary().getBasicSalary()>250000 && associate.getSalary().getBasicSalary()<=500000){
			netSalary = associate.getSalary().getBasicSalary()-(a*0.1);
		}
		else if(associate.getSalary().getBasicSalary()>500000 && associate.getSalary().getBasicSalary()<=1000000){
			netSalary = associate.getSalary().getBasicSalary()-((a*0.1)+(b*0.2));
		}
		else{
			netSalary = associate.getSalary().getBasicSalary()-((a*0.1)+(b*0.2)+(c*0.3));
		}
		return netSalary;*/
		
	}
	
	@Override
	public double calculateTax(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = getAssociateDetails(associateId);
		PayrollServicesImpl payroll = new PayrollServicesImpl();
		double tax = payroll.calculateNetSalary(associateId) - (12 * payroll.calculateGrossSalary(associateId));
		return tax;
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = associateDao.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("Associate details not found for ID. : " + associateId);
		return associate;
	}

	@Override
	public List<Associate> getAllAssociateDetails() throws AssociateDetailsNotFoundException {
		List<Associate> associates = associateDao.findAll();
		if(associates==null)
			throw new AssociateDetailsNotFoundException("Associate details not found. ");
		return associates;
	}

}
