package com.cg.departmentallocation.daoservices;

import java.util.List;

import com.cg.departmentallocation.beans.Student;

public interface StudentDAOServices {
	Student save(Student student);
	boolean update(Student student);
	Student findOne(int studentId);
	List<Student> findAll();
}
