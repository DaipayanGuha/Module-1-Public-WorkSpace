package com.cg.departmentallocation.beans;

public enum Gender {
	Male, Female, Others;
}
