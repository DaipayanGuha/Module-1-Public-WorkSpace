package com.cg.departmentallocation.beans;

public class Department {

	private int deptId;
	private String deptName;
	private String deptHOD;
	private int deptFloorNumber;
	public Department() {
		super();
	}
	public Department(int deptId, String deptName, String deptHOD, int deptFloorNumber) {
		super();
		this.deptId = deptId;
		this.deptName = deptName;
		this.deptHOD = deptHOD;
		this.deptFloorNumber = deptFloorNumber;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptHOD() {
		return deptHOD;
	}
	public void setDeptHOD(String deptHOD) {
		this.deptHOD = deptHOD;
	}
	public int getDeptFloorNumber() {
		return deptFloorNumber;
	}
	public void setDeptFloorNumber(int deptFloorNumber) {
		this.deptFloorNumber = deptFloorNumber;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + deptFloorNumber;
		result = prime * result + ((deptHOD == null) ? 0 : deptHOD.hashCode());
		result = prime * result + deptId;
		result = prime * result + ((deptName == null) ? 0 : deptName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Department other = (Department) obj;
		if (deptFloorNumber != other.deptFloorNumber)
			return false;
		if (deptHOD == null) {
			if (other.deptHOD != null)
				return false;
		} else if (!deptHOD.equals(other.deptHOD))
			return false;
		if (deptId != other.deptId)
			return false;
		if (deptName == null) {
			if (other.deptName != null)
				return false;
		} else if (!deptName.equals(other.deptName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "\n Department [deptId=" + deptId + ", deptName=" + deptName + ", deptHOD=" + deptHOD + ", deptFloorNumber="
				+ deptFloorNumber + "]";
	}
}
