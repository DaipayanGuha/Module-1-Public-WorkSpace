package com.cg.departmentallocation.tests;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.departmentallocation.beans.Department;
import com.cg.departmentallocation.beans.Student;
import com.cg.departmentallocation.beans.StudentGender;
import com.cg.departmentallocation.exceptions.StudentNotFoundException;
import com.cg.departmentallocation.services.DepartmentAllocationServices;
import com.cg.departmentallocation.services.DepartmentAllocationServicesImpl;
import com.cg.departmentallocation.studentdb.util.StudentDBUtil;

import static org.junit.Assert.*;

import org.junit.Test;

public class DepartmentAllocationTests {

	private static DepartmentAllocationServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services = new DepartmentAllocationServicesImpl();
	}
	@Before
	public void setUpTestData() {
		Student student1 = new Student(101 ,"Pritam Chakraborty", StudentGender.Male, "Kolkata", new Department(01, "C.S.E", "Swagata Pal", 1));
		Student student2 = new Student(102, "Rohini Ghosh", StudentGender.Female, "Delhi", new Department(02, "E.C.E", "Swapan Sen", 3));
		StudentDBUtil.studentDetails.put(student1.getStudentId(), student1);
		StudentDBUtil.studentDetails.put(student2.getStudentId(), student2);
		StudentDBUtil.STUDENT_ID = 102;
	}
	
	@Test(expected = StudentNotFoundException.class)
	public void testGetStudentDetailsForInvalidStudentId() throws StudentNotFoundException {
		services.getStudentDetail(105);
	}
	
	@Test
	public void testGetStudentDetailsForValidStudentId() throws StudentNotFoundException {
		Student expectedStudent = new Student(101 ,"Pritam Chakraborty", StudentGender.Male, "Kolkata", new Department(01, "C.S.E", "Swagata Pal", 1));
		Student actualStudent = services.getStudentDetail(101);
		Assert.assertEquals(expectedStudent, actualStudent);
	}

	@Test
	public void testAcceptStudentDetailsForValidStudentId() {
		int expectedId = 103;
		int actualId = services.acceptStudentDetails("Pritam Chakraborty", StudentGender.Male, "Kolkata", 01, "C.S.E", "Swagata Pal", 1);

		Assert.assertEquals(expectedId, actualId);
	}
	
	
	
	@Test
	public void testGetAllAssociateDetails() {
		Student student1 = new Student(101 ,"Pritam Chakraborty", StudentGender.Male, "Kolkata", new Department(01, "C.S.E", "Swagata Pal", 1));
		Student student2 = new Student(102, "Rohini Ghosh", StudentGender.Female, "Delhi", new Department(02, "E.C.E", "Swapan Sen", 3));
		ArrayList<Student> expectedStudentList = new ArrayList<Student>();
		expectedStudentList.add(student1);
		expectedStudentList.add(student2);
		ArrayList<Student> actualStudentList = (ArrayList<Student>) services.getAllStudentDetails();
		Assert.assertEquals(expectedStudentList, actualStudentList);
	}
	@After
	public void tearDownTestData() {
		StudentDBUtil.studentDetails.clear();
		StudentDBUtil.STUDENT_ID = 100;
	}
	@AfterClass
	public static void tearDwonTestEnv() {
		services = null;
	}

}
