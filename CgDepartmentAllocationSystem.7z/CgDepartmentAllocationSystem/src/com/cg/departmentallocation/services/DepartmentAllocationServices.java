package com.cg.departmentallocation.services;

import java.util.List;

import com.cg.departmentallocation.beans.Department;
import com.cg.departmentallocation.beans.Student;
import com.cg.departmentallocation.beans.StudentGender;
import com.cg.departmentallocation.exceptions.StudentNotFoundException;
public interface DepartmentAllocationServices {
	int acceptStudentDetails(String studentName, StudentGender studentGender, 
			String studentResidentialCity, int deptId, String deptName, 
			String deptHOD, int deptFloorNumber);
	
	Student getStudentDetail(int studentId) throws StudentNotFoundException;
	
	List<Student> getAllStudentDetails();
}
