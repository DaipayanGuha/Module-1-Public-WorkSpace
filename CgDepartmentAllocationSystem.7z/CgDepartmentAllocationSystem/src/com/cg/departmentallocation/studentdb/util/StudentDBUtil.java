package com.cg.departmentallocation.studentdb.util;

import java.util.HashMap;

import com.cg.departmentallocation.beans.Student;

public class StudentDBUtil {
	public static HashMap<Integer, Student> studentDetails = new HashMap<>();
	public static int STUDENT_ID = 100;
	public static int getSTUDENT_ID() {
		return ++STUDENT_ID;
	}
}
