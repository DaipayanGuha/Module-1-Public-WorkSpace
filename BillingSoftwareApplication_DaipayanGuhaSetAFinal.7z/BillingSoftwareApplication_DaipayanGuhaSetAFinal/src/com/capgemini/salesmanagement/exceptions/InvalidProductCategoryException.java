package com.capgemini.salesmanagement.exceptions;

@SuppressWarnings("serial")
public class InvalidProductCategoryException extends Exception{

	public InvalidProductCategoryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidProductCategoryException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidProductCategoryException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidProductCategoryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidProductCategoryException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
