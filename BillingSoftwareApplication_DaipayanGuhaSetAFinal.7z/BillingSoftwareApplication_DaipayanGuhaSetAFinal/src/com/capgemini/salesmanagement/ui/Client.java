package com.capgemini.salesmanagement.ui;

import java.util.HashMap;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductCodeException;
import com.capgemini.salesmanagement.exceptions.InvalidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidProductPriceException;
import com.capgemini.salesmanagement.exceptions.InvalidQuantityException;
import com.capgemini.salesmanagement.exceptions.InvalidSaleIdException;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class Client {

	public static void main(String[] args) {
		
		ISaleService services = new SaleService();
		
		Scanner sc = new Scanner(System.in);
		
		int productCode = 0;
		int productQuantity = 0;
		String productCategory = null;
		String productSubName = null;
		float productPrice;
		float lineTotal = 0;
		
		try {
			
						System.out.println("Enter Product Details :");
						
						System.out.println("Enter Product Code :");
						productCode = sc.nextInt();
						if(services.validateProductCode(productCode));
						
						System.out.println("Enter Product Quantity :");
						productQuantity = sc.nextInt();
						if(services.validateQuantity(productQuantity));
							
						System.out.println("Enter Product Category :");
						productCategory = sc.next();
						if(services.validateProductCat(productCategory));
						
						System.out.println("Enter Sub-Product Name :");
						productSubName = sc.next();
						if(services.validateProductName(productSubName));
							
						System.out.println("Enter Product Price :");
						productPrice = sc.nextFloat();
						if(services.validateProductPrice(productPrice));
							lineTotal = productQuantity * productPrice;
						System.out.println("Line Total = " + lineTotal);
					
					}catch(InvalidProductCodeException e) {
						System.out.println("Product Code is Invalid!");
					} catch (InvalidQuantityException e) {
						System.out.println("Product Quantity is Invalid!");
					} catch (InvalidProductCategoryException e) {
						System.out.println("Product Category is Invalid!");
					} catch (InvalidProductNameException e) {
						System.out.println("Product Name is Invalid!");
					} catch (InvalidProductPriceException e) {
						System.out.println("Product Price is Invalid!");
				}
			
		Sale sale = new Sale(productCode, productSubName, productCategory, CollectionUtil.currDate(), productQuantity, lineTotal);
		HashMap<Integer,Sale> salesMap = services.insertSalesDetails(sale);
		for(Integer i : salesMap.keySet()) {
			System.out.println("Sales Details : " + salesMap.get(i));
		}
		System.out.println("Fetching sales details when the Sail ID. : " + sale.getSaleId() + " is provided :");
		try {
			System.out.println(services.getSaleDetails(sale.getSaleId()));
		}catch(InvalidSaleIdException e) {
			e.printStackTrace();
		}
	
	}

}
