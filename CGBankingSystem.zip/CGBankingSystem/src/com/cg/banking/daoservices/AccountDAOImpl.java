package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.util.BankingDBUtil;

public class AccountDAOImpl implements AccountDAO {

	@Override
	public Account save(Account account) {
		account.setAccountNo(BankingDBUtil.getACCOUNT_ID_COUNTER());
		account.setPinNumber ((int)(Math.random()*10000));
		BankingDBUtil.customerDetails.put(account.getAccountNo(), account);
		return account;
	}

	@Override
	public boolean update(Account account) {
		if (BankingDBUtil.customerDetails.containsKey(account.getAccountNo())) {
			BankingDBUtil.customerDetails.put(account.getAccountNo(), account);
			return true;
		}
		return false;
	}

	@Override
	public List<Account> findAll() {
		return new ArrayList<Account>(BankingDBUtil.customerDetails.values());
	}

	@Override
	public Account findOne(long accountNo) {
		return BankingDBUtil.customerDetails.get(accountNo);
	}

}
