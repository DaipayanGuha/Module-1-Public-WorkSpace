package com.cg.banking.daoservices;
import java.util.List;
import com.cg.banking.beans.Transaction;
public interface TransactionDAO {
	Transaction save(long accountNo,Transaction transaction);
	boolean update(Transaction transaction);
	Transaction findOne(long accountNo,int transactionId);
	List<Transaction> findAll(long accountNo);
}
