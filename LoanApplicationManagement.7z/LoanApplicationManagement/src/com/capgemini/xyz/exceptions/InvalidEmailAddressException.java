package com.capgemini.xyz.exceptions;

public class InvalidEmailAddressException extends Exception {

	public InvalidEmailAddressException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidEmailAddressException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public InvalidEmailAddressException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	

	public InvalidEmailAddressException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
