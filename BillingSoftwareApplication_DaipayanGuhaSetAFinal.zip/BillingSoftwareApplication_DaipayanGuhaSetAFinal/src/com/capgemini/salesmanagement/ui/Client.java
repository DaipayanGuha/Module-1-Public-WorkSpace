package com.capgemini.salesmanagement.ui;

import java.util.Scanner;

import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductCodeException;
import com.capgemini.salesmanagement.exceptions.InvalidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidProductPriceException;
import com.capgemini.salesmanagement.exceptions.InvalidQuantityException;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {

	public static void main(String[] args) {
		
		ISaleService services = new SaleService();
		
		Scanner sc = new Scanner(System.in);
		
		int productCode;
		int productQuantity;
		String productCategory;
		String productSubName;
		float productPrice;
		float lineTotal;
		
		try {
			
						System.out.println("Enter Product Details :");
						
						System.out.println("Enter Product Code :");
						productCode = sc.nextInt();
						if(services.validateProductCode(productCode));
						
						System.out.println("Enter Product Quantity :");
						productQuantity = sc.nextInt();
						if(services.validateQuantity(productQuantity));
							
						System.out.println("Enter Product Category :");
						productCategory = sc.next();
						if(services.validateProductCat(productCategory));
						
						System.out.println("Enter Sub-Product Name :");
						productSubName = sc.next();
						if(services.validateProductName(productSubName));
							
						System.out.println("Enter Product Price :");
						productPrice = sc.nextFloat();
						if(services.validateProductPrice(productPrice));
							lineTotal = productQuantity * productPrice;
						System.out.println("Line Total = " + lineTotal);
					
					}catch(InvalidProductCodeException e) {
						System.out.println("Product Code is Invalid!");
					} catch (InvalidQuantityException e) {
						System.out.println("Product Quantity is Invalid!");
					} catch (InvalidProductCategoryException e) {
						System.out.println("Product Category is Invalid!");
					} catch (InvalidProductNameException e) {
						System.out.println("Product Name is Invalid!");
					} catch (InvalidProductPriceException e) {
						System.out.println("Product Price is Invalid!");
				}
	
	}

}
